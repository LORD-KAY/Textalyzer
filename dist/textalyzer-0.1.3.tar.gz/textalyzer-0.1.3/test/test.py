from Textalyzer import RegexpReplacer
from Textalyzer import RepeatCharacter

data=RegexpReplacer()
sample="This can't be"
lord=data.replace(sample)
print(lord)